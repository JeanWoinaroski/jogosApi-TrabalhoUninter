using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProjetoFacul.core
{
    /// <summary>
    /// Representa um funcionário vinculado a uma empresa
    /// </summary>
    public class Funcionario
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [StringLength(200)]
        public string Nome { get; set; } = default!;

        [Required]
        [EmailAddress]
        [StringLength(200)]
        public string Email { get; set; } = default!;

        [StringLength(100)]
        public string? Cargo { get; set; }

        [Required]
        public int EmpresaId { get; set; }

        // Navigation property
        public Empresa? Empresa { get; set; }
    }
}
