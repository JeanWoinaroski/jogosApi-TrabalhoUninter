using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjetoFacul.Data;
using ProjetoFacul.core;

namespace ProjetoFacul.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class FuncionariosController : ControllerBase
    {
        private readonly ProjetoFacul.Services.Interfaces.IFuncionarioService _service;

        public FuncionariosController(ProjetoFacul.Services.Interfaces.IFuncionarioService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var funcionarios = await _service.GetAllAsync();
            return Ok(funcionarios);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var funcionario = await _service.GetByIdAsync(id);
            if (funcionario == null) return NotFound();
            return Ok(funcionario);
        }

        [HttpGet("empresa/{empresaId}")]
        public async Task<IActionResult> GetByEmpresa(int empresaId)
        {
            var list = await _service.GetByEmpresaAsync(empresaId);
            return Ok(list);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Funcionario dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            try
            {
                var created = await _service.CreateAsync(dto);
                return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
            }
            catch (KeyNotFoundException ex)
            {
                return BadRequest(new { Mensagem = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Funcionario dto)
        {
            if (id != dto.Id) return BadRequest(new { Mensagem = "ID inválido." });
            if (!ModelState.IsValid) return BadRequest(ModelState);

            try
            {
                var updated = await _service.UpdateAsync(dto);
                return Ok(updated);
            }
            catch (KeyNotFoundException ex)
            {
                // If it's not found, return NotFound; if empresa invalid, return BadRequest
                if (ex.Message.Contains("Funcion")) return NotFound();
                return BadRequest(new { Mensagem = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _service.DeleteAsync(id);
                return NoContent();
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }
    }
}
