using Microsoft.EntityFrameworkCore;
using ProjetoFacul.core;

namespace ProjetoFacul.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Empresa> Empresas { get; set; } = default!;
        public DbSet<Funcionario> Funcionarios { get; set; } = default!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed sample data
            modelBuilder.Entity<Empresa>().HasData(
                new Empresa { Id = 1, Nome = "Acme Corp", Cnpj = "12.345.678/0001-90", Endereco = "Rua A, 123" },
                new Empresa { Id = 2, Nome = "Inovatech", Cnpj = "98.765.432/0001-10", Endereco = "Av. B, 456" }
            );

            modelBuilder.Entity<Funcionario>().HasData(
                new Funcionario { Id = 1, Nome = "João Silva", Email = "joao.silva@acme.com", Cargo = "Desenvolvedor", EmpresaId = 1 },
                new Funcionario { Id = 2, Nome = "Maria Santos", Email = "maria.santos@inovatech.com", Cargo = "Analista", EmpresaId = 2 }
            );
        }
    }
}
