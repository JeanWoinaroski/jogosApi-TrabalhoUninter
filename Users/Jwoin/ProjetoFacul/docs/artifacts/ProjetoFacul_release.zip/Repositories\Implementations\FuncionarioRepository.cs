using Microsoft.EntityFrameworkCore;
using ProjetoFacul.Data;
using ProjetoFacul.core;
using ProjetoFacul.Repositories.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProjetoFacul.Repositories.Implementations
{
    public class FuncionarioRepository : IFuncionarioRepository
    {
        private readonly AppDbContext _db;

        public FuncionarioRepository(AppDbContext db)
        {
            _db = db;
        }

        public async Task AddAsync(Funcionario funcionario)
        {
            _db.Funcionarios.Add(funcionario);
            await _db.SaveChangesAsync();
        }

        public async Task DeleteAsync(Funcionario funcionario)
        {
            _db.Funcionarios.Remove(funcionario);
            await _db.SaveChangesAsync();
        }

        public async Task<List<Funcionario>> GetAllAsync()
        {
            return await _db.Funcionarios.Include(f => f.Empresa).AsNoTracking().ToListAsync();
        }

        public async Task<Funcionario?> GetByIdAsync(int id)
        {
            return await _db.Funcionarios.Include(f => f.Empresa).FirstOrDefaultAsync(f => f.Id == id);
        }

        public async Task<List<Funcionario>> GetByEmpresaAsync(int empresaId)
        {
            return await _db.Funcionarios.Where(f => f.EmpresaId == empresaId).Include(f => f.Empresa).AsNoTracking().ToListAsync();
        }

        public async Task UpdateAsync(Funcionario funcionario)
        {
            _db.Entry(funcionario).State = EntityState.Modified;
            await _db.SaveChangesAsync();
        }

        public async Task<bool> ExistsAsync(int id)
        {
            return await _db.Funcionarios.AnyAsync(f => f.Id == id);
        }
    }
}
