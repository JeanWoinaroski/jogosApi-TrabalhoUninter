using ProjetoFacul.core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProjetoFacul.Services.Interfaces
{
    public interface IFuncionarioService
    {
        Task<List<Funcionario>> GetAllAsync();
        Task<Funcionario?> GetByIdAsync(int id);
        Task<List<Funcionario>> GetByEmpresaAsync(int empresaId);
        Task<Funcionario> CreateAsync(Funcionario funcionario);
        Task<Funcionario> UpdateAsync(Funcionario funcionario);
        Task DeleteAsync(int id);
    }
}
