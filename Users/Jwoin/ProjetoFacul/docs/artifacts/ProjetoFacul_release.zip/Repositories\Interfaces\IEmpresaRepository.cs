using ProjetoFacul.core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProjetoFacul.Repositories.Interfaces
{
    public interface IEmpresaRepository
    {
        Task<List<Empresa>> GetAllAsync();
        Task<Empresa?> GetByIdAsync(int id);
        Task AddAsync(Empresa empresa);
        Task UpdateAsync(Empresa empresa);
        Task DeleteAsync(Empresa empresa);
        Task<bool> ExistsAsync(int id);
    }
}
