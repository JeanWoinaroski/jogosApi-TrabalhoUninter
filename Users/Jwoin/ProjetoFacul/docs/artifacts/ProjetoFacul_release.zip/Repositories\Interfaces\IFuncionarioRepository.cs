using ProjetoFacul.core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProjetoFacul.Repositories.Interfaces
{
    public interface IFuncionarioRepository
    {
        Task<List<Funcionario>> GetAllAsync();
        Task<Funcionario?> GetByIdAsync(int id);
        Task<List<Funcionario>> GetByEmpresaAsync(int empresaId);
        Task AddAsync(Funcionario funcionario);
        Task UpdateAsync(Funcionario funcionario);
        Task DeleteAsync(Funcionario funcionario);
        Task<bool> ExistsAsync(int id);
    }
}
