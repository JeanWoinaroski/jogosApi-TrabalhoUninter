using Microsoft.EntityFrameworkCore;
using ProjetoFacul.Data;
using ProjetoFacul.core;
using ProjetoFacul.Repositories.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProjetoFacul.Repositories.Implementations
{
    public class EmpresaRepository : IEmpresaRepository
    {
        private readonly AppDbContext _db;

        public EmpresaRepository(AppDbContext db)
        {
            _db = db;
        }

        public async Task AddAsync(Empresa empresa)
        {
            _db.Empresas.Add(empresa);
            await _db.SaveChangesAsync();
        }

        public async Task DeleteAsync(Empresa empresa)
        {
            _db.Empresas.Remove(empresa);
            await _db.SaveChangesAsync();
        }

        public async Task<List<Empresa>> GetAllAsync()
        {
            return await _db.Empresas.AsNoTracking().ToListAsync();
        }

        public async Task<Empresa?> GetByIdAsync(int id)
        {
            return await _db.Empresas.FindAsync(id);
        }

        public async Task UpdateAsync(Empresa empresa)
        {
            _db.Entry(empresa).State = EntityState.Modified;
            await _db.SaveChangesAsync();
        }

        public async Task<bool> ExistsAsync(int id)
        {
            return await _db.Empresas.AnyAsync(e => e.Id == id);
        }
    }
}
