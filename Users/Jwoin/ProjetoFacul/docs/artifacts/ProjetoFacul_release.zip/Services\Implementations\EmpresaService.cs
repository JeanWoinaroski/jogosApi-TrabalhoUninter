using ProjetoFacul.core;
using ProjetoFacul.Repositories.Interfaces;
using ProjetoFacul.Services.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProjetoFacul.Services.Implementations
{
    public class EmpresaService : IEmpresaService
    {
        private readonly IEmpresaRepository _repo;

        public EmpresaService(IEmpresaRepository repo)
        {
            _repo = repo;
        }

        public async Task<Empresa> CreateAsync(Empresa empresa)
        {
            await _repo.AddAsync(empresa);
            return empresa;
        }

        public async Task DeleteAsync(int id)
        {
            var existing = await _repo.GetByIdAsync(id);
            if (existing == null) throw new KeyNotFoundException("Empresa não encontrada.");
            await _repo.DeleteAsync(existing);
        }

        public async Task<List<Empresa>> GetAllAsync()
        {
            return await _repo.GetAllAsync();
        }

        public async Task<Empresa?> GetByIdAsync(int id)
        {
            return await _repo.GetByIdAsync(id);
        }

        public async Task<Empresa> UpdateAsync(Empresa empresa)
        {
            var exists = await _repo.ExistsAsync(empresa.Id);
            if (!exists) throw new KeyNotFoundException("Empresa não encontrada.");
            await _repo.UpdateAsync(empresa);
            return empresa;
        }
    }
}
