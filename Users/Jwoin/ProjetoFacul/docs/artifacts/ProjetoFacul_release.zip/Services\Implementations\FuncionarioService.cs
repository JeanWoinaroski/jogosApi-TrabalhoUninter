using ProjetoFacul.core;
using ProjetoFacul.Repositories.Interfaces;
using ProjetoFacul.Services.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProjetoFacul.Services.Implementations
{
    public class FuncionarioService : IFuncionarioService
    {
        private readonly IFuncionarioRepository _repo;
        private readonly IEmpresaRepository _empresaRepo;

        public FuncionarioService(IFuncionarioRepository repo, IEmpresaRepository empresaRepo)
        {
            _repo = repo;
            _empresaRepo = empresaRepo;
        }

        public async Task<Funcionario> CreateAsync(Funcionario funcionario)
        {
            var empresaExists = await _empresaRepo.ExistsAsync(funcionario.EmpresaId);
            if (!empresaExists) throw new KeyNotFoundException("EmpresaId inválido.");

            await _repo.AddAsync(funcionario);
            return funcionario;
        }

        public async Task DeleteAsync(int id)
        {
            var existing = await _repo.GetByIdAsync(id);
            if (existing == null) throw new KeyNotFoundException("Funcionário não encontrado.");
            await _repo.DeleteAsync(existing);
        }

        public async Task<List<Funcionario>> GetAllAsync()
        {
            return await _repo.GetAllAsync();
        }

        public async Task<Funcionario?> GetByIdAsync(int id)
        {
            return await _repo.GetByIdAsync(id);
        }

        public async Task<List<Funcionario>> GetByEmpresaAsync(int empresaId)
        {
            return await _repo.GetByEmpresaAsync(empresaId);
        }

        public async Task<Funcionario> UpdateAsync(Funcionario funcionario)
        {
            var exists = await _repo.ExistsAsync(funcionario.Id);
            if (!exists) throw new KeyNotFoundException("Funcionário não encontrado.");

            var empresaExists = await _empresaRepo.ExistsAsync(funcionario.EmpresaId);
            if (!empresaExists) throw new KeyNotFoundException("EmpresaId inválido.");

            await _repo.UpdateAsync(funcionario);
            return funcionario;
        }
    }
}
