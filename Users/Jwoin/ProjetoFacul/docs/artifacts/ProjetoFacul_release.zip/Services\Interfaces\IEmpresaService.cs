using ProjetoFacul.core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProjetoFacul.Services.Interfaces
{
    public interface IEmpresaService
    {
        Task<List<Empresa>> GetAllAsync();
        Task<Empresa?> GetByIdAsync(int id);
        Task<Empresa> CreateAsync(Empresa empresa);
        Task<Empresa> UpdateAsync(Empresa empresa);
        Task DeleteAsync(int id);
    }
}
