using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProjetoFacul.core
{
    /// <summary>
    /// Representa uma empresa no sistema
    /// </summary>
    public class Empresa
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [StringLength(200)]
        public string Nome { get; set; } = default!;

        [StringLength(20)]
        public string? Cnpj { get; set; }

        [StringLength(300)]
        public string? Endereco { get; set; }
    }
}
